#ifndef __PRINT__
#define __PRINT__

extern int printf(const char* s, ...);

#endif
