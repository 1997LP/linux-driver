#ifndef __INNOSYS_H_
#define __INNOSYS_H_

/////////////////////////////////////////////////////
/* System controller */

#define UART0_BASE 0x11110000
#define UART1_BASE 0x00000000


#endif
